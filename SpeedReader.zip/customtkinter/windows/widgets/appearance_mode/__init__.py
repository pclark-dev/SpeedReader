from .appearance_mode_base_class import CTkAppearanceModeBaseClass
from .appearance_mode_tracker import AppearanceModeTracker

AppearanceModeTracker.init_appearance_mode()
